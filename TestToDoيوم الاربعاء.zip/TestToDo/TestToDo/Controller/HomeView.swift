//
//  HomeView.swift
//  TestToDo
//
//  Created by عبدالوهاب العنزي on 28/07/2020.
//  Copyright © 2020 Abdulwahab. All rights reserved.
//

import UIKit
import LocalAuthentication

class HomeView: UIViewController {
    
    @IBOutlet weak var text: UIButton!
    @IBOutlet weak var photo: UIButton!

//    let context = LAContext()
//    var error: NSError?
//    var reason = "Authenticate"
//    let entryContents = "Hello!"
//    
//    let key = "test_entry"
//    let secret = "Hello!"
//    let password = "qwerty"
//    
//    enum Result {
//        case Success(String?)
//        case Failure(OSStatus)
//    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // self.tabBarController?.navigationItem.hidesBackButton = true
//        let addSecretSuccess = addSecret(secret: secret, usingPassword: password)
//               print(addSecretSuccess)
//               let readSecret = retrieveSecretUsing(password: password)
//               print(readSecret)
        
        text.layer.cornerRadius = 18
        photo.layer.cornerRadius = 18
        
      //  authenticate()

    }
//    func addSecret(secret: String, usingPassword password : String) -> Result {
//           if let secretData = secret.data(using: .utf8) as NSData? {
//               var error : Unmanaged<CFError>?
//               let acl = SecAccessControlCreateWithFlags(kCFAllocatorDefault, kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly, .applicationPassword, &error)
//               if error != nil {
//                   return .Failure(errSecNotAvailable)
//               }
//               context.setCredential(password.data(using: .utf8), type: .applicationPassword)
//               var attributes = [String : AnyObject]()
//               attributes[kSecClass as String] = kSecClassGenericPassword as CFString
//               attributes[kSecAttrAccount as String] = "exampleAccount" as CFString
//               attributes[kSecAttrService as String] = "secretService" as CFString
//               attributes[kSecValueData as String] = secretData
//               attributes[kSecAttrAccessControl as String] = acl
//               attributes[kSecUseAuthenticationContext as String] = context
//               let status = SecItemAdd(attributes as CFDictionary, nil)
//               if status == errSecSuccess {
//                   return .Success(nil)
//               } else {
//                   return .Failure(status)
//               }
//           }
//           return .Success(nil)
//       }
//
//       func retrieveSecretUsing(password : String) -> Result {
//           var error : Unmanaged<CFError>?
//           let acl = SecAccessControlCreateWithFlags(kCFAllocatorDefault, kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly, .applicationPassword, &error)
//           if error != nil {
//               return .Failure(errSecNotAvailable)
//           }
//           context.setCredential(password.data(using: .utf8), type: .applicationPassword)
//           var attributes = [String : AnyObject]()
//           attributes[kSecClass as String] = kSecClassGenericPassword as CFString
//           attributes[kSecAttrAccount as String] = "exampleAccount" as CFString
//           attributes[kSecAttrService as String] = "secretService" as CFString
//           attributes[kSecReturnData as String] = kCFBooleanTrue
//           attributes[kSecMatchLimit as String] = kSecMatchLimitOne
//           attributes[kSecAttrAccessControl as String] = acl
//           attributes[kSecUseAuthenticationContext as String] = context
//           var resultEntry : AnyObject? = nil
//           let status = SecItemCopyMatching(attributes as CFDictionary, &resultEntry)
//           if let data = resultEntry as? Data, let str = NSString(data: data, encoding: String.Encoding.utf8.rawValue) as String? { // (3)
//               return .Success(str)
//           } else {
//               return .Failure(status)
//           }
//       }
//    func authenticate()
//    {
//        let context = LAContext()
//        let reason = "We need this to protect your data." // add your own message explaining why you need this authentication method
//
//        var authError: NSError?
//        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &authError) {
//            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, error in
//
//
//                DispatchQueue.main.async
//                    {
//                        if success
//                        {
//                            // User authenticated successfully
//
//                        } else
//                        {
//                            // User did not authenticate successfully
//                            let authenticate_error = UIAlertController(title: "Authentication failed", message:"You could not be verified! please try again.", preferredStyle: .alert)
//                            authenticate_error.addAction(UIAlertAction(title: "OK", style: .default))
//                            self.present(authenticate_error, animated: true)
//                }
//                }
//            }
//        } else
//        {
//            // Handle Error - no biometry
//
//            let biometry_error = UIAlertController(title:"Biometry unavailable", message: "Your device is not configured for biometric authentication.", preferredStyle: .alert)
//            biometry_error.addAction(UIAlertAction(title: "OK", style: .default))
//            self.present(biometry_error, animated: true)
//
//        }
 //   }
    //MARK:- Hide The Line For NavigationBar
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Make the navigation bar background clear
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Restore the navigation bar to default
        navigationController?.navigationBar.setBackgroundImage(nil, for: .default)
        navigationController?.navigationBar.shadowImage = nil
    }
    
    
    
}


// MARK: - Hiding Back Button

extension UINavigationItem {

    /// A Boolean value that determines whether the back button is hidden.
    ///
    /// When set to `true`, the back button is hidden when this navigation item
    /// is the top item. This is true regardless of the value in the
    /// `leftItemsSupplementBackButton` property. When set to `false`, the back button
    /// is shown if it is still present. (It can be replaced by values in either
    /// the `leftBarButtonItem` or `leftBarButtonItems` properties.) The default value is `false`.
    @IBInspectable var hideBackButton: Bool {
        get { hidesBackButton }
        set { hidesBackButton = newValue }
    }
}
