//
//  ShowPhoto.swift
//  TestToDo
//
//  Created by عبدالوهاب العنزي on 30/07/2020.
//  Copyright © 2020 Abdulwahab. All rights reserved.
//

import UIKit
import CoreData

@available(iOS 13.0, *)
class ShowPhoto: UIViewController {

    @IBOutlet weak var showPhoto: UIImageView!
    
    
         var toDo = ITEMSPHOTO()
       
       // This is For Inhernens VC
       var toDoTableVC : ItemsPhoto? = nil
    
       // This for ( Read , Write , Save .. data (Defuntion)
          let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
       
    override func viewDidLoad() {
        super.viewDidLoad()

        
        title = toDo.titelPhoto
        
        if let imageData = toDo.imageDB {
            showPhoto.image = UIImage(data: imageData)
        }
    
    }
    
    
    //MARK:- Hide The Line For NavigationBar
     
     override func viewWillAppear(_ animated: Bool) {
         super.viewWillAppear(animated)
         
         // Make the navigation bar background clear
         navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
         navigationController?.navigationBar.shadowImage = UIImage()
         navigationController?.navigationBar.isTranslucent = true
         
     }
     
     override func viewWillDisappear(_ animated: Bool) {
         super.viewWillDisappear(animated)
         
         // Restore the navigation bar to default
         navigationController?.navigationBar.setBackgroundImage(nil, for: .default)
         navigationController?.navigationBar.shadowImage = nil
     }
    
    @IBAction func de(_ sender: UIBarButtonItem)
    {

        if toDo.perntREATIONSHIPphoto != nil {
            
            toDo.perntREATIONSHIPphoto = toDoTableVC?.selectedCategory
            context.delete(toDo)
            
            let aleart = UIAlertController(title: "تم حذف الملاحظه", message: "", preferredStyle: .alert)
            let action = UIAlertAction(title: "موافق", style: .default) { (action) in
                self.navigationController?.popViewController(animated: true)
            }
            aleart.addAction(action)
            present(aleart, animated: true, completion: nil)
            toDoTableVC?.tableView.reloadData()
        }
        
        
        
    }
    
 

}
