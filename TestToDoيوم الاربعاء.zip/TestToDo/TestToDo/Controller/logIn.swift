//
//  logIn.swift
//  TestToDo
//
//  Created by عبدالوهاب العنزي on 21/08/2020.
//  Copyright © 2020 Abdulwahab. All rights reserved.
//

import UIKit
import LocalAuthentication

class logIn: UIViewController {
   
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
    // authenticate()
        
        
//        let context = LAContext()
//        var error: NSError?
//
//        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
//            let reason = "Identify yourself!"
//
//            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
//                [weak self] success, authenticationError in
//
//                DispatchQueue.main.async {
//                    if success {
//
//                        self!.performSegue(withIdentifier: "goToHome", sender: nil)
//
//
//                    } else {
//
//                        //                              let aleart = UIAlertController(title: "الرجاء التحقق مره اخرى", message: "", preferredStyle: .alert)
//                        //                              let action = UIAlertAction(title: "موافق", style: .default) { (action) in
//                        //
//                        //                              }
//                        //                              aleart.addAction(action)
//                        // self!.present(aleart, animated: true, completion: nil)
//
//                    }
//                }
//            }
//        } else
//        {
//
//            performSegue(withIdentifier: "goToHome", sender: nil)
//        }
        
    }
    override func didReceiveMemoryWarning()
       {
           super.didReceiveMemoryWarning()
           // Dispose of any resources that can be recreated.
       }
    
    func authenticate() {
        let context = LAContext()
        var error: NSError?

        // check whether biometric authentication is possible
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            // it's possible, so go ahead and use it
            let reason = "We need to unlock your data."

            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, authenticationError in
                // authentication has now completed
                DispatchQueue.main.async {
                    if success {
                        // authenticated successfully
                        self.performSegue(withIdentifier: "goToHome", sender: nil)
                   //     self.isUnlocked = true
                    } else {
                        // there was a problem
                    }
                }
            }
        } else {
            // no biometrics
        }
    }

           
//           // Make the navigation bar background clear
//           navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
//           navigationController?.navigationBar.shadowImage = UIImage()
//           navigationController?.navigationBar.isTranslucent = true
//        func isFaceIdSupported() -> Bool {
//            if #available(iOS 11.0, *){
//                if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil) {
//                    return context.biometryType == LABiometryType.typeFaceID
//                }
//            }
//
//            return false
//        }
    func authenticateUser() {
        let context = LAContext()
        var error: NSError?
       if #available(iOS 11.0, *) {
      //  if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
         
              
                    
                    
                
            let reason = "Identify yourself!"
            

            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
                [unowned self] success, authenticationError in

                DispatchQueue.main.async {
                    if success {
                   
                         self.performSegue(withIdentifier: "goToHome", sender: nil)
                        
                    } else {
                        let ac = UIAlertController(title: "Authentication failed", message: "Sorry!", preferredStyle: .alert)
                        ac.addAction(UIAlertAction(title: "OK", style: .default))
                        self.present(ac, animated: true)
                    }
                }}
            
        } else {

              self.performSegue(withIdentifier: "goToHome", sender: nil)
        }
        
    
    }
    
    @IBAction func facId(_ sender: UIButton)
    {
        
    authenticateUser()
//        let context = LAContext()
//        var error: NSError?
//
//        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
//            let reason = "Identify yourself!"
//
//            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) {
//                [weak self] success, authenticationError in
//
//                DispatchQueue.main.async {
//                    if success {
//
//                        self!.performSegue(withIdentifier: "goToHome", sender: nil)
//
//
//                    } else {
//
//                        let aleart = UIAlertController(title: "الرجاء التحقق", message: "", preferredStyle: .alert)
//                        let action = UIAlertAction(title: "موافق", style: .default) { (action) in
//
//                        }
//                        aleart.addAction(action)
//                        self!.present(aleart, animated: true, completion: nil)
//
//                    }
//                }
//            }
//        } else
//        {
//
//            performSegue(withIdentifier: "goToHome", sender: nil)
//        }
//    }
    

    
}


}
