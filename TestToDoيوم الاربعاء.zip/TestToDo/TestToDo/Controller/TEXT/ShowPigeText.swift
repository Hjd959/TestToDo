//
//  ShowPigeText.swift
//  TestToDo
//
//  Created by عبدالوهاب العنزي on 19/07/2020.
//  Copyright © 2020 Abdulwahab. All rights reserved.
//

import UIKit
import CoreData
@available(iOS 13.0, *)
class ShowPigeText: UIViewController ,UITextFieldDelegate, UITextViewDelegate{

   
//        public class Alert {
//        class func alert(userTitle: String?, userMessage: String, userOptions: String, in vc: UIViewController) {
//            DispatchQueue.main.async {
//                let alert = UIAlertController(title: userTitle, message: userMessage, preferredStyle: UIAlertController.Style.alert)
//                alert.addAction(UIAlertAction(title: userOptions, style: UIAlertAction.Style.default, handler: nil))
//                vc.present(alert, animated: true, completion: nil)
//            }
//
//        }
//
//    }
    
    @IBOutlet weak var bigText: UITextView!
    
        
        var toDo = ITEMS()
        
        // This is For Inhernens VC
        var toDoTableVC : Items? = nil
        
        // This for ( Read , Write , Save .. data (Defuntion)
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
       
        self.bigText.textAlignment = .right
     //   titelText.text = toDo.titelText
        title = toDo.titelText
        bigText.text = toDo.textView
        
       
        
          // For Keybord
      
        

    self.bigText.addDoneButton(title: "موافق", target: self, selector: #selector(tapDone(sender:)))
    

            
        }
    
        // 2
        @objc func tapDone(sender: Any) {
            self.view.endEditing(true)
        }
    
    
    //MARK:- Hide The Line For NavigationBar
      override func viewWillDisappear(_ animated: Bool) {
          super.viewWillDisappear(animated)
          
          // Restore the navigation bar to default
          navigationController?.navigationBar.setBackgroundImage(nil, for: .default)
          navigationController?.navigationBar.shadowImage = nil
      }
      
      // Save Data when you get out of the app
      override func viewWillAppear(_ animated: Bool)
      {
          
          // Make the navigation bar background clear
          navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
          navigationController?.navigationBar.shadowImage = UIImage()
          navigationController?.navigationBar.isTranslucent = true
          toDoTableVC?.tableView.reloadData()
      }
    
    
    @IBAction func de(_ sender: UIBarButtonItem)
    {
        
  dfdf()
        
//        if toDo.perntCategoryRELATIONSHIP != nil {
//
//            toDo.perntCategoryRELATIONSHIP = toDoTableVC?.selectedCategory
//            context.delete(toDo)
//
//            let aleart = UIAlertController(title: "تم حذف الملاحظه", message: "", preferredStyle: .alert)
//            let action = UIAlertAction(title: "موافق", style: .default) { (action) in
//                self.navigationController?.popViewController(animated: true)
//
//            }
//            aleart.addAction(action)
//            present(aleart, animated: true, completion: nil)
//            toDoTableVC?.tableView.reloadData()
//        }
        
        
        
    }
    
    func dfdf()
    {
        
        if toDo.perntCategoryRELATIONSHIP != nil {
            
            toDo.perntCategoryRELATIONSHIP = toDoTableVC?.selectedCategory
            context.delete(toDo)
            
            let aleart = UIAlertController(title: "تم حذف الملاحظه", message: "", preferredStyle: .alert)
            let action = UIAlertAction(title: "موافق", style: .default) { (action) in
                self.navigationController?.popViewController(animated: true)
                
            }
            aleart.addAction(action)
            present(aleart, animated: true, completion: nil)
            toDoTableVC?.tableView.reloadData()
        }
    }
     //MARK:- Keybord Hide

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func upDate()
    {
    
        
    }
    
    @IBAction func updata(_ sender: UIBarButtonItem)
    {
     var na = ""
         na = bigText.text

         if ((UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext) != nil
         {
             toDo.setValue(na, forKey: "textView")
             (UIApplication.shared.delegate as? AppDelegate)?.saveContext()
            
            let aleart = UIAlertController(title: "تم حفظ التعديلات", message: "", preferredStyle: .alert)
            let action = UIAlertAction(title: "موافق", style: .default) { (action) in
                self.navigationController?.popViewController(animated: true)
            }
            aleart.addAction(action)
            present(aleart, animated: true, completion: nil)
            self.navigationController?.popViewController(animated: true)
           
         }
    }
    
}



extension UITextView {

    func addDoneButton(title: String, target: Any, selector: Selector) {

        let toolBar = UIToolbar(frame: CGRect(x: 0.0,
                                              y: 0.0,
                                              width: UIScreen.main.bounds.size.width,
                                              height: 44.0))//1
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)//2
        let barButton = UIBarButtonItem(title: title, style: .plain, target: target, action: selector)//3
        toolBar.setItems([flexible, barButton], animated: false)//4
        self.inputAccessoryView = toolBar//5
    }
    
    
}
